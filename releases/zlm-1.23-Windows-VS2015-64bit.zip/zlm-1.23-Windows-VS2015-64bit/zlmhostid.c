#include <stdio.h>
#include <stdlib.h>
#include "zlm.h"

int main(int argc, char *argv[])
{
  char err[ZLM_ERRBUF];
  int had_err;

  if (argc != 1) {
    fprintf(stderr, "Usage: %s\n", argv[0]);
    fprintf(stderr, "Print host ID on stdout.\n");
    return EXIT_FAILURE;
  }

  /* print host ID on stdout and write it to file zlmhostid.txt in CWD. */
  had_err = zlm_hostid_file(err);

  if (had_err) {
    fprintf(stderr, "%s: error: %s\n", argv[0], err);
    return -had_err;
  }

  return EXIT_SUCCESS;
}
