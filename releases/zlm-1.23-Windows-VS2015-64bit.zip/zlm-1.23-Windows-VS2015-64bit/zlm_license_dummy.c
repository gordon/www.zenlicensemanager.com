#include <stdio.h>

const char* zlm_lib_license(void)
{
  return NULL;
}
