#include <stdio.h>
#include <stdlib.h>
#include "zlm.h"

int main(int argc, char *argv[])
{
  ZlmLicense *license;
  char err[ZLM_ERRBUF];

  /* create license object */
  if (!(license = zlm_license_new(err))) {
    fprintf(stderr, "error: %s\n", err);
    return EXIT_FAILURE;
  }

  /* try to get license for product 'My Product' from the same directory as the
     executed binary and if that fails from the current directory */
  if (zlm_license_get(license, "My Product", "1.0", argv[0], ".", NULL, err)) {
    fprintf(stderr, "error: %s\n", err);
    zlm_license_free(license);
    return EXIT_FAILURE;
  }
  else
    puts("got license!");

  /**********************
   * run your code here *
   **********************/

  /* free license object */
  zlm_license_free(license);

  return EXIT_SUCCESS;
}
