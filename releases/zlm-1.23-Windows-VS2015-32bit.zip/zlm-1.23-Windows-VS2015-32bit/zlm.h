/*
  Copyright (c) 2013-2020 Wikena GmbH <support@zenlicensemanager.com>
  All rights reserved.
*/

#ifndef ZLM_H
#define ZLM_H

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __ANDROID__
#include <jni.h>
#endif

#ifdef __APPLE__
#include <TargetConditionals.h>
#endif

/* The minimum size of an error buffer. */
#define ZLM_ERRBUF 1024

/* The minimum size of a salt string. */
#define ZLM_SALTLEN  65

/* ZLM error codes. */
#define ZLM_OK           0 /* everything went fine */
#define ZLM_NOMEM       -2 /* memory allocation error */
#define ZLM_IOERR       -3 /* I/O error */
#define ZLM_APIERR      -4 /* API was used incorrectly */
#define ZLM_NOLIBLIC    -5 /* library license malformed/invalid */
#define ZLM_NOLICFILE   -6 /* no license file found */
#define ZLM_BADLICFILE  -7 /* malformed licfile */
#define ZLM_BADVENDOR   -8 /* vendor mismatch between library lic. and file */
#define ZLM_NOVERIFY    -9 /* signature verification failed */
#define ZLM_OLDVERSION -10 /* version in license is too old */
#define ZLM_EXPIRED    -11 /* the license expired */
#define ZLM_WRONGHOST  -12 /* wrong host ID / appcert */
#define ZLM_NOPRODUCT  -13 /* no license found for product */
#define ZLM_HOSTIDERR  -14 /* error while determining host ID */
#define ZLM_KEYGENERR  -15 /* error while generating public/private key pair */
#define ZLM_SIGNERR    -16 /* error while signing */
#define ZLM_MINVERSION -17 /* product version is too old for minversion */
#define ZLM_WRONGOS    -18 /* wrong operating system */
#define ZLM_JNIERR     -19 /* JNI related error (Android only) */
#define ZLM_WRONGCPU   -20 /* wrong CPU architecture */

/* The type of a ZLM license object. */
typedef struct ZlmLicense ZlmLicense;

/* Return a new license object (or NULL if not enough memory is available). */
ZlmLicense* zlm_license_new(char *err);

/* Try to get a new <license> for the given <product>.
   The version given in the corresponding license file or string must be smaller
   or equal than the one given in the mandatory <produt_version> parameter such
   that the license is valid. <product_version> must be of the form
   "major.minor" (e.g., "1.0"). If no valid license can be obtained an error
   code is returned and an error message describing the problem is stored in
   <err> (if <err> is not NULL). If <err> is not NULL, it must have at least
   ZLM_ERRBUF many bytes.  If a valid license was obtained, ZLM_OK is returned
   and <license> points to the active license.
   zlm_license_get() tries to aquire the license in the following order:

   1.) If the environment variable <ZLM_LICENSE> is defined it is used as path:
       If it points directly to a file, the file is probed for a valid license.
       If it points to a directory, then all files ending with '.lic' are probed
       for a valid license.
   2.) If <argv0> is not NULL it should point to the first member of your
       main's argv. In this case, the directory in which the main binary resides
       is used as license directory.
   3.) If <path> is not NULL it is used as license path (as in case 1.)).
       Use "." to search the current directory for valid license files.
   4.) If <license_string> is not NULL the given string is used as the content
       of a license file.

   zlm_license_get() can only be called once on a fresh <license> object. */
int         zlm_license_get(ZlmLicense *license, const char *product,
                            const char *product_version, const char *argv0,
                            const char *path, const char *license_string,
                            char *err);

/* Release <license> and free corresponding memory. */
void        zlm_license_free(ZlmLicense *license);

/* Return the product of the given <license>. <license> must be a license which
   has been validated with zlm_license_get(), otherwise NULL is returned. */
const char* zlm_license_product(const ZlmLicense *license);

/* Return the version of the given <license>. <license> must be a license which
   has been validated with zlm_license_get(), otherwise NULL is returned. */
const char* zlm_license_version(const ZlmLicense *license);

/* Return the expiry of the given <license>. <license> must be a license which
   has been validated with zlm_license_get(), otherwise NULL is returned. */
const char* zlm_license_expiry(const ZlmLicense *license);

/* Return the number of days the given <license> will expire in. Returns 0 if
   the license never expires. <license> must be a license which has been
   validated with zlm_license_get(), otherwise ZLM_APIERR is returned. */
int         zlm_license_expiry_days(const ZlmLicense *license);

/* Return the customer of the given <license>. <license> must be a license which
   has been validated with zlm_license_get(), otherwise NULL is returned. */
const char* zlm_license_customer(const ZlmLicense *license);

/* Return the userdata associated with the given valid <license>. Possible JSON
   escape sequences are included in unmodified form. If the <license> has not
   been validated with zlm_license_get() or it does not have userdata
   associated with it NULL is returned. */
const char* zlm_license_userdata(const ZlmLicense *license);

/* Return the userdata associated with the given valid <license> in unescaped
   form. That is, possible JSON escape sequences have been removed: The escaped
   characters '\"', '\\', '\/', '\b', '\f', '\n', '\r', and '\t' have been
   unescaped and '\uXXXX' sequences have been converted to 1-3 bytes UTF-8.
   If the <license> has not been validated with zlm_license_get(), it does not
   have userdata associated with it, or no memory could be allocated NULL is
   returned. The caller is responsible to free the returned string with
   zlm_free()! */
char*       zlm_license_userdata_unescaped(const ZlmLicense *license);

/* Sets <license> to the next available valid license.
   <license> must be a license which has been validated with
   zlm_license_get(), otherwise ZLM_APIERR is returned.
   If no further valid license can be obtained an error code is returned and an
   error message describing the problem is stored in <err> (if <err> is not
   NULL). If <err> is not NULL, it must have at least ZLM_ERRBUF many bytes.
   This method can be used to extend the ZLM checks with your own userdata. For
   example, if you want to implement different host IDs.*/
int         zlm_license_next(ZlmLicense *license, char *err);

/* Check if <license> has expired. <license> must be a license which has been
   validated with zlm_license_get(), otherwise ZLM_APIERR is returned. If the
   license expired since it was validated with zlm_license_get(), ZLM_EXPIRED
   is returned and an error message describing the expiry is stored in <err> (if
   <err> is not NULL). If <err> is not NULL, it must have at least ZLM_ERRBUF
   many bytes. */
int         zlm_license_not_expired(const ZlmLicense *license, char *err);

/* Return the version of the ZLM library in use as a string. */
const char* zlm_version(void);

/* Return the unhashed host ID string of this computer in JSON format (in a
   single line). The caller is responsible to free the returned string with
   zlm_free()! In case of error, NULL is returned and the error buffer <err> is
   set accordingly. */
char*       zlm_hostid_json(char *err);

/* Return the hashed host ID string of this computer in JSON format (in a
   single line). The caller is responsible to free the returned string with
   zlm_free()! In case of error, NULL is returned and the error buffer <err> is
   set accordingly. The salt used for the hashing is stored in <salt> which must
   not be NULL and have at least ZLM_SALTLEN many bytes.
   Deprecated: Use zlm_hostid_json() instead! */
char*       zlm_hostid_json_hashed(char *salt, char *err);

/* Free the memory memory space pointed to by <ptr>, which must have been
   returned by a previous call to another ZLM library function. */
void        zlm_free(void *ptr);

/* License check methods which make it harder to remove ZLM from your binary.
   You should call these methods in different places of your program with a
   valid <license>. Thereby, <license> must be a license which has been
   validated with zlm_license_get(), otherwise the methods will crash!
   zlm_license_check_a() to zlm_license_check_f() just check, if the license was
   valid before.
   zlm_license_check_g() to zlm_license_check_l() also recheck the expiry.
   That is, if the license expired in the meantime, these checks would crash.
   If you want to shut down gracefully in such cases, use
   zlm_license_not_expired() instead to recheck the expiry.
   zlm_license_check_m() to zlm_license_check_r() also recheck the hostid
   (but not the expiry). That is, if the hostid became invalid in the meantime,
   these checks would crash. */
void        zlm_license_check_a(const ZlmLicense *license);
void        zlm_license_check_b(const ZlmLicense *license);
void        zlm_license_check_c(const ZlmLicense *license);
void        zlm_license_check_d(const ZlmLicense *license);
void        zlm_license_check_e(const ZlmLicense *license);
void        zlm_license_check_f(const ZlmLicense *license);
void        zlm_license_check_g(const ZlmLicense *license);
void        zlm_license_check_h(const ZlmLicense *license);
void        zlm_license_check_i(const ZlmLicense *license);
void        zlm_license_check_j(const ZlmLicense *license);
void        zlm_license_check_k(const ZlmLicense *license);
void        zlm_license_check_l(const ZlmLicense *license);
void        zlm_license_check_m(const ZlmLicense *license);
void        zlm_license_check_n(const ZlmLicense *license);
void        zlm_license_check_o(const ZlmLicense *license);
void        zlm_license_check_p(const ZlmLicense *license);
void        zlm_license_check_q(const ZlmLicense *license);
void        zlm_license_check_r(const ZlmLicense *license);

/* The type of a key function (public or private). */
typedef const unsigned char* (ZlmKeyfunc)(int *keylen);

/* Generate public/private key pair and write it to the files zlm_pubkey.c and
   zlm_privkey.c in the current directory. */
int zlm_genkeys(char *err);

/* Print host ID string of this computer on stdout. */
int zlm_hostid(char *err);

/* Print host ID string of this computer on stdout and to write it to a file
   named zlmhostid.txt in the current working directory.
   If the file already exists it is overwritten! */
int zlm_hostid_file(char *err);

/* Print hash of <public_key> on stdout. */
int zlm_keyhash(ZlmKeyfunc *public_key, char *err);

/* Sign the license file given in <path> with the given <private_key>.
   If <path> is NULL the license file is read from stdin and the result written
   to stdout. */
int zlm_sign_file(const char *path, ZlmKeyfunc *private_key, char *err);

/* Verify signatures of license file given in <path> with given <public_key>.
   If <path> is NULL the license file is read from stdin. */
int zlm_verify_file(const char *path, ZlmKeyfunc *public_key, char *err);

/* Sign the license file given in buffer <license> with the given <private_key>
   and return the result. The caller is responsible to free the returned string
   with zlm_free()! In case of error, NULL is returned and the error buffer
   <err> is set accordingly. */
char* zlm_sign_license(const char *license, ZlmKeyfunc *private_key, char *err);

#ifdef __ANDROID__
/* Android only: In order to use ANDROID_ID entries in the "hostid" field of
   license files you have to call this this function once before using any other
   library function! <env> must be the JNI environment, otherwise ZLM_APIERR is
   returned. <activity> must be an Android activity (that is, an object with the
   getContentResolver() method), otherwise ZLM_APIERR or ZLM_JNIERR is returned.
   If the ANDROID_ID cannot be determined ZLM_JNIERR is returned and err
   contains an error message. */
int zlm_read_android_id(JNIEnv *env, jobject activity, char *err);

/* Android only: Return the ANDROID_ID. Before this method can be used
   the ANDROID_ID has to be read once by calling zlm_read_android_id(). */
const char* zlm_android_id(void);

/* Android only: In order to use application ID entries in the "hostid" field of
   license files you have to call this this function once before using any other
   library function! <env> must be the JNI environment, otherwise ZLM_APIERR is
   returned. <activity> must be an Android activity (that is, an object with the
   getPackageName() method), otherwise ZLM_APIERR or ZLM_JNIERR is returned.
   If the application ID cannot be determined ZLM_JNIERR is returned and err
   contains an error message. */
int zlm_read_application_id(JNIEnv *env, jobject activity, char *err);

/* Android only: Return the application ID. Before this method can be used the
   application ID has to be read once by calling zlm_read_application_id(). */
const char* zlm_application_id(void);

/* Android only: In order to use application certificate entries in the
   "appcert" field of license files you have to call this this function once
   before using any other library function! <env> must be the JNI environment,
   otherwise ZLM_APIERR is returned. If the application certificate cannot be
   determined ZLM_JNIERR is returned and err contains an error message. */
int zlm_read_application_cert(JNIEnv *env, jobject activity, char *err);

/* Android only: Return the (oldest) application certificate as SHA-256.
   Before this method can be used the application ID has to be read once by
   calling zlm_read_application_cert(). */
const char* zlm_application_cert(void);
#endif

#if defined (__APPLE__) && (TARGET_OS_IOS > 0)
/* iOS only: Return the vendor specific unique key (a UUID conforming to RFC
   4122 version 4) as a C-string. See http://apple.co/2ohHcQY for details.

   If the result is NULL wait and get the value again later. This happens, for
   example, after the device has been restarted but before the user has unlocked
   the device.

   The value in this property remains the same while the app (or another app
   from the same vendor) is installed on the iOS device. The value changes when
   the user deletes all of that vendor’s apps from the device and subsequently
   reinstalls one or more of them. The value can also change when installing
   test builds using Xcode or when installing an app on a device using ad-hoc
   distribution. */
const char* zlm_ios_hostid(char *err);

/* iOS only: Return the unique bundle identifier (CFBundleIdentifier).
   See https://apple.co/2SU5j50 for details. */
const char* zlm_ios_bundle_identifier(char *err);
#endif

#ifdef __cplusplus
}
#endif

#endif
