/*
  Copyright (c) 2014-2016 Wikena GmbH

  Permission to use, copy, modify, and distribute this software for any
  purpose with or without fee is hereby granted, provided that the above
  copyright notice and this permission notice appear in all copies.

  THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
  WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
  MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
  ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
  WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
  ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
  OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
*/

using System;
using System.Runtime.InteropServices;

namespace Wikena
{
  public class ZLM
  {
    /* The minimum size of an error buffer. */
    public const int ZLM_ERRBUF = 1024;

	  /* ZLM error codes. */
	  public const int ZLM_OK         =   0; /* everything went fine */
	  public const int ZLM_NOMEM      =  -2; /* memory allocation error */
	  public const int ZLM_IOERR      =  -3; /* I/O error */
	  public const int ZLM_APIERR     =  -4; /* API was used incorrectly */
	  public const int ZLM_NOLIBLIC   =  -5; /* library license malformed/invalid */
	  public const int ZLM_NOLICFILE  =  -6; /* no license file found */
	  public const int ZLM_BADLICFILE =  -7; /* malformed licfile */
	  public const int ZLM_BADVENDOR  =  -8; /* vendor mismatch between library lic. and file */
	  public const int ZLM_NOVERIFY   =  -9; /* signature verification failed */
	  public const int ZLM_OLDVERSION = -10; /* version in license is too old */
	  public const int ZLM_EXPIRED    = -11; /* the license expired */
	  public const int ZLM_WRONGHOST  = -12; /* wrong host ID */
	  public const int ZLM_NOPRODUCT  = -13; /* no license found for product */
	  public const int ZLM_HOSTIDERR  = -14; /* error while dertermining host ID */
	  public const int ZLM_KEYGENERR  = -15; /* error while generating public/private key pair */
	  public const int ZLM_SIGNERR    = -16; /* error while signing */
	  public const int ZLM_MINVERSION = -17; /* product version is too old for minversion */
	  public const int ZLM_WRONGOS    = -18; /* wrong operating system */

    /* ZLM API. */
	  [DllImport("zlm_md1.dll", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.Cdecl)]
    public static extern IntPtr zlm_license_new(byte[] err);

	  [DllImport("zlm_md1.dll", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.Cdecl)]
    public static extern int zlm_license_get(IntPtr license, String product, String version, String argv0, String path, String license_string, byte[] err);

	  [DllImport("zlm_md1.dll", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.Cdecl)]
    public static extern void zlm_license_free(IntPtr license);

	  [DllImport("zlm_md1.dll", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.Cdecl)]
    public static extern String zlm_license_product(IntPtr license);

	  [DllImport("zlm_md1.dll", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.Cdecl)]
    public static extern String zlm_license_version(IntPtr license);

	  [DllImport("zlm_md1.dll", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.Cdecl)]
    public static extern String zlm_license_expiry(IntPtr license);

	  [DllImport("zlm_md1.dll", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.Cdecl)]
    public static extern int zlm_license_expiry_days(IntPtr license);

	  [DllImport("zlm_md1.dll", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.Cdecl)]
    public static extern String zlm_license_customer(IntPtr license);

	  [DllImport("zlm_md1.dll", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.Cdecl)]
    public static extern String zlm_license_userdata(IntPtr license);

	  [DllImport("zlm_md1.dll", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.Cdecl)]
    public static extern int zlm_license_next(IntPtr license, byte[] err);

	  [DllImport("zlm_md1.dll", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.Cdecl)]
    public static extern String zlm_version();

	  [DllImport("zlm_md1.dll", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.Cdecl)]
    public static extern void zlm_license_check_a(IntPtr license);

	  [DllImport("zlm_md1.dll", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.Cdecl)]
    public static extern void zlm_license_check_b(IntPtr license);

	  [DllImport("zlm_md1.dll", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.Cdecl)]
    public static extern void zlm_license_check_c(IntPtr license);

	  [DllImport("zlm_md1.dll", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.Cdecl)]
    public static extern void zlm_license_check_d(IntPtr license);

	  [DllImport("zlm_md1.dll", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.Cdecl)]
    public static extern void zlm_license_check_e(IntPtr license);

	  [DllImport("zlm_md1.dll", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.Cdecl)]
    public static extern void zlm_license_check_f(IntPtr license);

	  [DllImport("zlm_md1.dll", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.Cdecl)]
    public static extern void zlm_license_check_g(IntPtr license);

	  [DllImport("zlm_md1.dll", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.Cdecl)]
    public static extern void zlm_license_check_h(IntPtr license);

	  [DllImport("zlm_md1.dll", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.Cdecl)]
    public static extern void zlm_license_check_i(IntPtr license);

	  [DllImport("zlm_md1.dll", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.Cdecl)]
    public static extern void zlm_license_check_j(IntPtr license);

	  [DllImport("zlm_md1.dll", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.Cdecl)]
    public static extern void zlm_license_check_k(IntPtr license);

	  [DllImport("zlm_md1.dll", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.Cdecl)]
    public static extern void zlm_license_check_l(IntPtr license);

	  [DllImport("zlm_md1.dll", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.Cdecl)]
    public static extern void zlm_license_check_m(IntPtr license);

	  [DllImport("zlm_md1.dll", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.Cdecl)]
    public static extern void zlm_license_check_n(IntPtr license);

	  [DllImport("zlm_md1.dll", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.Cdecl)]
    public static extern void zlm_license_check_o(IntPtr license);

	  [DllImport("zlm_md1.dll", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.Cdecl)]
    public static extern void zlm_license_check_p(IntPtr license);

	  [DllImport("zlm_md1.dll", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.Cdecl)]
    public static extern void zlm_license_check_q(IntPtr license);

	  [DllImport("zlm_md1.dll", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.Cdecl)]
    public static extern void zlm_license_check_r(IntPtr license);

    public static String errbufToString(byte[] errbuf)
	  {
	  	return System.Text.Encoding.ASCII.GetString(errbuf).TrimEnd((Char)0);
	  }
  }
}
