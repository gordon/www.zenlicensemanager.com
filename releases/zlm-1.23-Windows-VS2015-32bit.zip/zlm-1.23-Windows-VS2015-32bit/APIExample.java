import com.zenlicensemanager.zlm.*; /* import all classes from zlm1.jar */

public class APIExample
{
  public static void main(String[] args)
  {
    ZlmLicense license = null;
    try {
      license = new ZlmLicense();
      license.get("My Product", "1.0", null, ".", null);
    } catch (ZlmException e) {
      System.out.println("error: " + e.getMessage());
      System.exit(1);
    }
    System.out.println("got license!");
    license.free();
  }
  static {
    /* load shared ZLM library */
    if (System.getProperty("os.name").startsWith("Windows")) {
      System.loadLibrary("zlm_mt1");
    } else {
      System.loadLibrary("zlm1");
    }
  }
}
