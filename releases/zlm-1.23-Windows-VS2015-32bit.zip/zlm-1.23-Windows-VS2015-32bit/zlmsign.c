#include <stdio.h>
#include <stdlib.h>
#include "zlm.h"

extern const unsigned char* zlm_get_private_key(int *keylen);

int main(int argc, char *argv[])
{
  char err[ZLM_ERRBUF];
  int had_err;

  if (argc > 2) {
    fprintf(stderr, "Usage: %s [license_file_to_sign]\n", argv[0]);
    fprintf(stderr, "Sign the given license file (or read from stdin).\n");
    return EXIT_FAILURE;
  }
  else if (argc == 1)
    fprintf(stderr, "reading license file from stdin...\n");

  /* sign license file */
  had_err = zlm_sign_file(argv[1], zlm_get_private_key, err);

  if (had_err) {
    fprintf(stderr, "%s: error: %s\n", argv[0], err);
    return -had_err;
  }

  return EXIT_SUCCESS;
}
