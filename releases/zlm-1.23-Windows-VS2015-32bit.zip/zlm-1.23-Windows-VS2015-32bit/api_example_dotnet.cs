using System;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using Wikena;

namespace APIExample
{
    class APIExample
    {
        static void Main(string[] args)
        {
            IntPtr license;
            byte[] errbuf = new byte[ZLM.ZLM_ERRBUF];
            int rval;

            /* create license object */
            license = ZLM.zlm_license_new(errbuf);
            if (license == null) {
              Console.WriteLine("error: " + ZLM.errbufToString(errbuf));
              Environment.ExitCode = 1;
              return;
            }

            /* try to get license for product 'My Product' from the same directory as the
               executed binary and if that fails from the current directory */
            rval = ZLM.zlm_license_get(license, "My Product", "1.0", Application.ExecutablePath, ".", null, errbuf);
            if (rval != 0) {
              Console.WriteLine("error: " + ZLM.errbufToString(errbuf));
              ZLM.zlm_license_free(license);
              Environment.ExitCode = 1;
              return;
            }
            else {
              Console.WriteLine("got license!");
            }

            /**********************
             * run your code here *
             **********************/

            /* free license object */
            ZLM.zlm_license_free(license);
        }
    }
}
