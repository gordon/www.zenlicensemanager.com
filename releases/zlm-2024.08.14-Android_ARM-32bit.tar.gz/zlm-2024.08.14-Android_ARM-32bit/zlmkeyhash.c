#include <stdio.h>
#include <stdlib.h>
#include "zlm.h"

extern const unsigned char* zlm_get_public_key(int *keylen);

int main(int argc, char *argv[])
{
  char err[ZLM_ERRBUF];
  int had_err;

  if (argc != 1) {
    fprintf(stderr, "Usage: %s\n", argv[0]);
    fprintf(stderr, "Print hash of public key on stdout.\n");
    return EXIT_FAILURE;
  }

  /* print public key hash */
  had_err = zlm_keyhash(zlm_get_public_key, err);

  if (had_err) {
    fprintf(stderr, "%s: error: %s\n", argv[0], err);
    return -had_err;
  }

  return EXIT_SUCCESS;
}
