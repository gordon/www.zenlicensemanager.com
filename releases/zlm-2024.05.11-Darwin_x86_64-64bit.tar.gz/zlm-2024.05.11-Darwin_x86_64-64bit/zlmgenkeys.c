#include <stdio.h>
#include <stdlib.h>
#include "zlm.h"

int main(int argc, char *argv[])
{
  char err[ZLM_ERRBUF];
  int had_err;

  if (argc != 1) {
    fprintf(stderr, "Usage: %s\n", argv[0]);
    fprintf(stderr, "Generate private and public keys for signatures.\n");
    return EXIT_FAILURE;
  }

  /* generate keys */
  had_err = zlm_genkeys(err);

  if (had_err) {
    fprintf(stderr, "%s: error: %s\n", argv[0], err);
    return -had_err;
  }

  return EXIT_SUCCESS;
}
